from django.urls import path
from django.urls import path,include
from . import views

urlpatterns=[
    path('',views.index,name='index'),
    path('user/',views.user,name='user'),
    path('hr/',views.hr,name='hr'),
    path('pm/',views.pm,name='pm'),
    path('ceo/',views.ceo,name='ceo'),
    path('client/',views.client,name='client'),
    path('contact/',views.contact,name='contact'),

]


