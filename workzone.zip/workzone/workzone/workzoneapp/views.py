from django.shortcuts import render
from django.http import HttpResponse



# Create your views here.
def index(request):
    return render(request,'index.html')
def user(request):
    return render(request,'user.html')
def hr(request):
    return render(request,'hr.html')
def pm(request):
    return render(request,'pm.html')
def ceo(request):
    return render(request,'ceo.html')
def client(request):
    return render(request,'client.html')
def contact(request):
    return render(request,'contact.html')
