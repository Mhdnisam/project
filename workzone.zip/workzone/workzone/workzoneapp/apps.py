from django.apps import AppConfig


class WorkzoneappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'workzoneapp'
