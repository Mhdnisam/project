from django import forms
from .models import Client, Employee, PM, HR

class ClientForm(forms.ModelForm):  # Follow naming convention for class names
    class Meta:
        model = Client
        fields = ['name', 'email', 'password', 'phone_number']

    def clean_phone_number(self):
        phone = self.cleaned_data.get('phone_number')
        if len(phone) < 10:  # Example validation
            raise forms.ValidationError("Phone number must be at least 10 digits.")
        return phone

from django import forms
from .models import Employee

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = ['name', 'email', 'password', 'phone_number']

    def clean_phone_number(self):
        phone = self.cleaned_data.get('phone_number')
        if len(phone) < 10:  # Example validation
            raise forms.ValidationError("Phone number must be at least 10 digits.")
        return phone

class PMForm(forms.ModelForm):
    class Meta:
        model = PM
        fields = ['name', 'email', 'password', 'phone_number']

    def clean_phone_number(self):
        phone = self.cleaned_data.get('phone_number')
        if len(phone) < 10:  # Example validation
            raise forms.ValidationError("Phone number must be at least 10 digits.")
        return phone

class HRForm(forms.ModelForm):
    class Meta:
        model = HR
        fields = ['name', 'email', 'password', 'phone_number']

    def clean_phone_number(self):
        phone = self.cleaned_data.get('phone_number')
        if len(phone) < 10:  # Example validation
            raise forms.ValidationError("Phone number must be at least 10 digits.")
        return phone


