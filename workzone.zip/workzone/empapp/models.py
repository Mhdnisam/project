from django.db import models

class Client(models.Model):  # Model names should be singular and CamelCase
    name = models.CharField(max_length=30)
    post = models.CharField(max_length=30)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)  # Use a longer length for passwords
    phone_number = models.CharField(max_length=15)  # Use CharField for phone numbers

    def __str__(self):
        return self.name



class Employee(models.Model):
    name = models.CharField(max_length=30)
    post = models.CharField(max_length=30)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)  # You might want to hash the password before saving
    phone_number = models.CharField(max_length=15)  # You might want to consider validating phone numbers more strictly

    def __str__(self):
        return self.name

class PM(models.Model):
    name = models.CharField(max_length=30)
    post = models.CharField(max_length=30)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15)

    def __str__(self):
        return self.name

class HR(models.Model):
    name = models.CharField(max_length=30)
    post = models.CharField(max_length=30)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15)

    def __str__(self):
        return self.name



    
