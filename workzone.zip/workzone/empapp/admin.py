# admin.py

from django.contrib import admin
from .models import Client, Employee, PM, HR 

# Register your models here
admin.site.register(Client)
admin.site.register(Employee)
admin.site.register(PM)
admin.site.register(HR)

