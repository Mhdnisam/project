


from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from .forms import ClientForm, EmployeeForm, PMForm, HRForm
from .models import Client, Employee, PM, HR


def index(request):
     return render(request, 'index.html')

# Registration Views
def client_register(request):
    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = ClientForm()
        
    return render(request, 'client.html', {'form': form})
def employee_register(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()  # Save the employee data to the database
            return redirect('employeelogin')  # Redirect to employee login after successful registration
        else:
            # Print form errors to the console for debugging
            print("Form errors:", form.errors)
            return render(request, 'employee.html', {'form': form})
    else:
        form = EmployeeForm()  # Initialize an empty form if GET request

    return render(request, 'employee.html', {'form': form})

def pm_register(request):
    if request.method == 'POST':
        form = PMForm(request.POST)
        if form.is_valid():
            form.save()  # Save the employee data to the database
            return redirect('pmlogin')  # Redirect to employee login after successful registration
        else:
            # Print form errors to the console for debugging
            print("Form errors:", form.errors)
            return render(request, 'pm.html', {'form': form})
    else:
        form = PMForm()  # Initialize an empty form if GET request

    return render(request, 'pm.html', {'form': form})

def hr_register(request):
    if request.method == 'POST':
        form = HRForm(request.POST)
        if form.is_valid():
            form.save()  # Save the employee data to the database
            return redirect('hrlogin')  # Redirect to employee login after successful registration
        else:
            # Print form errors to the console for debugging
            print("Form errors:", form.errors)
            return render(request, 'hr.html', {'form': form})
    else:
        form = HRForm()  # Initialize an empty form if GET request

    return render(request, 'hr.html', {'form': form})


# Login View
def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        
        # Use Django's authenticate function to verify credentials
        user = authenticate(request, username=email, password=password)
        
        if user is not None:
            auth_login(request, user)
            return redirect('dashboard')
        else:
            return render(request, 'login.html')
    
    return render(request, 'login.html')

def employeelogin(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        
        # Use Django's authenticate function to verify credentials
        user = authenticate(request, username=email, password=password)
        
        if user is not None:
            auth_login(request, user)
            return redirect('dashboard')
        else:
            return render(request, 'employeelogin.html')
    
    return render(request, 'employeelogin.html')

def pmlogin(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        
        # Use Django's authenticate function to verify credentials
        user = authenticate(request, username=email, password=password)
        
        if user is not None:
            auth_login(request, user)
            return redirect('pmdashboard')
        else:
            return render(request, 'pmlogin.html')
    
    return render(request, 'pmlogin.html')

def hrlogin(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        
        # Use Django's authenticate function to verify credentials
        user = authenticate(request, username=email, password=password)
        
        if user is not None:
            auth_login(request, user)
            return redirect('dashboard')
        else:
            return render(request, 'hrlogin.html')
    
    return render(request, 'hrlogin.html')

# Dashboard View
def client_dashboard(request):
        return render(request, 'client_dashboard.html')
def employee_dashboard(request):
        return render(request, 'employee_dashboard.html')
def pm_dashboard(request):
        return render(request, 'pm_dashboard.html')
def hr_dashboard(request):
        return render(request, 'hr_dashboard.html')



