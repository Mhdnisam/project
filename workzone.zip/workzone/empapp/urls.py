




from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('register/client/', views.client_register, name='client_register'),
    path('register/employee/', views.employee_register, name='employee_register'),
    path('register/pm/', views.pm_register, name='pm_register'),
    path('register/hr/', views.hr_register, name='hr_register'),
    
    
    path('login/', views.login, name='login'),
    path('employeelogin/', views.employeelogin, name='employeelogin'),
    path('pmlogin/', views.pmlogin, name='pmlogin'),
    path('hrlogin/', views.hrlogin, name='hrlogin'),

    
    path('login/clientdashboard/', views.client_dashboard, name='clientdashboard'),
    path('employeelogin/employeedashboard/', views.employee_dashboard, name='employeedashboard'),
    path('pmlogin/pmdashboard/', views.pm_dashboard, name='pmdashboard'),
    path('hrlogin/hrdashboard/', views.hr_dashboard, name='hrdashboard'),

]
